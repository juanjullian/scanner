# -----------------------------------------------------------------------------
# Copyright (c) 2025, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

from arena_api._xlayer.xarena._xsocket import _xSocket
from arena_api import buffer as _buffer
from arena_api import buffer
from arena_api.buffer import BufferFactory


class Socket():
    """
    The Socket class provides an interface for network socket operations,
    allowing for the sending and receiving of data over the network.
    This class abstracts away the lower-level socket operations provided
    by the `_xSocket` class, offering a more Pythonic interface for
    network communication.

    Example usage:

    >>> # Open a socket for sending data
    >>> socket.open_sender()
    >>> socket.add_destination(12345)
    >>> socket.send_message('Hello, world!')
    >>> socket.close_sender()
    
    >>> # Open a socket for receiving data
    >>> socket.open_listener(12345)
    >>> message = socket.receive_message()
    >>> print(message)
    >>> socket.close_listener()

    Sockets are essential for network communication, used to send and
    receive data between devices over a network.
    """

    def __init__(self):
        self.xsocket = _xSocket()  

    def __del__(self):
        self.xsocket.xSocketDestroy()

    def open_sender(self):
        """
        Opens the socket for sending data.
        """
        self.xsocket.xSocketOpenSender()

    def close_sender(self):
        """
        Closes the sender socket, stopping data transmission.
        """
        self.xsocket.xSocketCloseSender()

    def add_destination(self, port):
        """
        Adds a destination port for sending data.

        Args:
            port (int): The port number to send data to.
        """
        self.xsocket.xSocketAddDestination(port)

    def send_message(self, message):
        """
        Sends a message over the network.

        Args:
            message (str): The message to send.
        """
        self.xsocket.xSocketSendMessage(message)

    def send_singleImage(self, buffer):
        """
        Sends a single buffer over the network.

        Args:
            buffer (acBuffer): The buffer to send.
        """
        self.xsocket.xSocketSendImage(buffer.xbuffer.hxbuffer.value)

    def open_listener(self, port):
        """
        Opens the socket for listening to incoming data.

        Args:
            port (int): The port number to listen on.
        """
        self.xsocket.xSocketOpenListener(port)

    def close_listener(self):
        """
        Closes the listener socket, stopping data reception.
        """
        self.xsocket.xSocketCloseListener()

    def receive_message(self):
        """
        Receives a message from the network.

        Returns:
            str: The received message.
        """
        return self.xsocket.xSocektReceiveMessage()
    
    def receive_singleImage(self):
        """
        Receives a single buffer from the network.

        Returns:
            acBuffer:  an image with chunk.
        """
        hxbuffer = self.xsocket.xSocketReceiveImage()
        buf = _buffer._Buffer(hxbuffer)
        return buf
    
