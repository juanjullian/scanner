# -----------------------------------------------------------------------------
# Copyright (c) 2025, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------


from arena_api.system import system
from arena_api.buffer import *
from arena_api.socket import Socket

import time

'''
Live Stream: Introduction
    This example introduces the basics of running a live stream from a single device.
    This includes creating a device, turn on arenaview plugin over socket mamand line, 
    aquire an image and display the image on AVMP over the image socket.
'''

TAB1 = "  "
TAB2 = "    "


def create_devices_with_tries():
	'''
	This function waits for the user to connect a device before raising
		an exception
	'''

	tries = 0
	tries_max = 6
	sleep_time_secs = 10
	while tries < tries_max:  # Wait for device for 60 seconds
		devices = system.create_device()
		if not devices:
			print(
				f'{TAB1}Try {tries+1} of {tries_max}: waiting for {sleep_time_secs} '
				f'secs for a device to be connected!')
			for sec_count in range(sleep_time_secs):
				time.sleep(1)
				print(f'{TAB1}{sec_count + 1 } seconds passed ',
					'.' * sec_count, end='\r')
			tries += 1
		else:
			print(f'{TAB1}Created {len(devices)} device(s)')
			return devices
	else:
		raise Exception(f'{TAB1}No device found! Please connect a device and run '
						f'the example again.')



'''
Setup stream dimensions and stream nodemap
'''
def device_nodemap_setup(device):
    nodemap = device.nodemap
    nodes = nodemap.get_node(['Width', 'Height', 'PixelFormat'])

    print('Setting Width to its maximum value')
    nodes['Width'].value = nodes['Width'].max

    print('Setting Height to its maximum value')
    height = nodes['Height']
    height.value = height.max

    nodes['PixelFormat'].value = 'Mono8'

    # Stream nodemap
    tl_stream_nodemap = device.tl_stream_nodemap

    tl_stream_nodemap["StreamBufferHandlingMode"].value = "NewestOnly"
    tl_stream_nodemap['StreamAutoNegotiatePacketSize'].value = True
    tl_stream_nodemap['StreamPacketResendEnable'].value = True






def example_entry_point():
    """
    demonstrates live stream
    (1) Start device stream
    (2) Continuously acquire image buffers from the device.
    (3) Send each buffer to ArenaViewMP for real-time display via the image socket.
    """

    devices = create_devices_with_tries()
    device = system.select_device(devices)

    device_nodemap_setup(device)

    # Intialize the command socket

    command_socket = Socket()
    command_socket.open_sender()
    command_socket.add_destination(12345)

    
    # Send the inital command message

    start_message = 'option update socket_view --value=1 --async'
    command_socket.send_message(start_message)
    print(f'message: "{start_message}" sent successfully!\n')


    # Initialize the image socket
    image_socket = Socket()
    image_socket.open_sender()
    image_socket.add_destination(54000)

    print("Streaming started. Press 'q' and Enter to stop the stream.")

    with device.start_stream():
        """
        Continuously acquire and send buffer data until timeout or keyboard interrupt
        """
        try:
            while True:
                # Check if user pressed q to stop the stream
                user_input = input()
                if user_input.lower() == 'q':
                    print("User requested to stop the stream.")
                    break

                buffer = device.get_buffer()
                """
                Copy buffer and requeue to avoid running out of buffers
                """
                item = BufferFactory.copy(buffer)
                device.requeue_buffer(buffer)

                # Send the buffer data via socket directly
                image_socket.send_singleImage(item)
                print('Image sent successfully!')

                """
                Destroy the copied item to prevent memory leaks
                """
                BufferFactory.destroy(item)


        except KeyboardInterrupt:
            print('Keyboard Interrupt: Stopping the stream')
      
    device.stop_stream()    

    # Turn off the socket_view Plugin on ArenaViewMP 
            
    end_message = 'option update socket_view --value=0'
    command_socket.send_message(end_message)
    print(f'message: "{end_message}" sent successfully!\n')

    image_socket.close_sender()
    command_socket.close_sender()
    print(f"Clean up Arena")

    # Destroy Device
    system.destroy_device()
    print(f'Destroyed all created devices')



if __name__ == '__main__':
	print('\nWARNING:\nTHIS EXAMPLE MIGHT CHANGE THE DEVICE(S) SETTINGS!')
	print('\nExample started\n')
	example_entry_point()
	print('\nExample finished successfully')