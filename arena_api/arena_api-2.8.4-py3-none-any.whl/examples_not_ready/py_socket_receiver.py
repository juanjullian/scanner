# -----------------------------------------------------------------------------
# Copyright (c) 2025, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

import time
from datetime import datetime

from arena_api.enums import PixelFormat
from arena_api.__future__.save import Writer
from arena_api.system import system
from arena_api.buffer import BufferFactory
from arena_api.socket import Socket

'''
Receiver: Introduction
	This example illustrates receiving data through the User Datagram Protocol (UDP),
 	emphasizing fast, connectionless communication that does not guarantee packet order
	or integrity.  
'''

'''
=-=-=-=-=-=-=-=-=-
=-=- SETTINGS =-=-
=-=-=-=-=-=-=-=-=-
'''
TAB1 = "  "
TAB2 = "    "
pixel_format = PixelFormat.BGR8

def save(buffer, save_counter):
	'''
	demonstrates saving an image
	(1) converts image to a displayable pixel format
	(2) prepares image parameters
	(3) prepares image writer
	(4) saves image
	(5) destroys converted image
	'''
	'''
	Convert image
		Convert the image to a displayable pixel format. It is worth keeping in
		mind the best pixel and file formats for your application. This example
		converts the image so that it is displayable by the operating system.
	'''
	converted = BufferFactory.convert(buffer, pixel_format)
	print(f"{TAB1}Converted image to {pixel_format.name}")

	'''
	Prepare image writer
		The image writer requires 2 parameters to save an image: the buffer and
		specified file name or pattern. Default name for the image is
		'image_<count>.jpg' where count is a pre-defined tag that gets updated
		every time a buffer image.
	'''
	print(f'{TAB1}Prepare Image Writer')
	writer = Writer()
	save_counter['saved'] += 1
	count = save_counter['saved']
	writer.pattern = f'images/py_save/image_{count}.jpg'

	# Save converted buffer
	writer.save(converted)
	print(f'{TAB1}Image saved as {writer.pattern}')

	# Destroy converted buffer to avoid memory leaks
	BufferFactory.destroy(converted)


def example_entry_point():
	save_counter = {'saved': 0}
	receive_counter = 0
	
	socket = Socket()
	socket.open_listener(54000)
	print(f'{TAB1}Server is listening on port 54000 ...')
	message = socket.receive_message()
	print(f'{TAB1}Received message: {message} successfully!')

	number_of_buffers = 5
	for _ in range(number_of_buffers): 
		buffer = socket.receive_singleImage()
		receive_counter += 1
		print(f'{TAB1}Received image: {receive_counter} successfully!')
		save(buffer, save_counter)
		BufferFactory.destroy(buffer)


if __name__ == "__main__":
	print("Example Started\n")
	example_entry_point()
	print("\nExample Completed")
