from multiprocessing import Process, Queue
import time
from arena_api.system import system
from arena_api.buffer import BufferFactory
import numpy as np
import cv2

def consumer(queue):
    
    while True:
        image_array = queue.get()
        cv2.imshow("Lucid", image_array)
        k = cv2.waitKey(1)
        if k == 27:
            break
    cv2.destroyAllWindows()      

def producer(queue):
    devices = system.create_device()
    device = devices[0]
    device.start_stream()
    while True:
        buffer = device.get_buffer()
        copy = BufferFactory.copy(buffer)
        device.requeue_buffer(buffer)
        buffer_bytes_per_pixel = int(len(copy.data)/(copy.width * copy.height))
        np_array = np.asarray(copy.data, dtype=np.uint8)
        np_array_reshaped = np_array.reshape(copy.height, copy.width, buffer_bytes_per_pixel) 
        queue.put(np_array)
        time.sleep(0.0001)

if __name__=='__main__':
    pqueue = Queue()

    c = Process(target=producer, args=((pqueue),))
    c.start()      

    consumer(pqueue)    
    c.join()         
