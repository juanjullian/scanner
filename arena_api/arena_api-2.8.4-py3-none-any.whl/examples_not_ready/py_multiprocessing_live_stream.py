import multiprocessing
from arena_api.system import system
from arena_api.buffer import BufferFactory
import numpy as np
import cv2
import time


mutex = multiprocessing.Semaphore()
empty = multiprocessing.Semaphore(10)
full = multiprocessing.Semaphore(0)

def consumer(q):
	
	while True:
		q.get()
		print("cons")



def producer(q):
	devices = system.create_device()
	device = devices[0]
	device.start_stream()

	while True:
		buffer = device.get_buffer()
		copy = BufferFactory.copy(buffer)
		device.requeue_buffer(buffer)
		
		buffer_bytes_per_pixel = int(len(copy.data)/(copy.width * copy.height))
		np_array = np.asarray(copy.data, dtype=np.uint8)
		np_array_reshaped = np_array.reshape(copy.height, copy.width, buffer_bytes_per_pixel)

		q.put(np_array_reshaped)
		print("prod")

		time.sleep(0.001)



if __name__ == '__main__':
	with multiprocessing.Manager() as manager:

		q = manager.Queue()
		

		# check https://stackoverflow.com/questions/3671666/sharing-a-complex-object-between-processes
		# check https://stackoverflow.com/questions/11951750/sharing-object-class-instance-using-multiprocessing-managers

		p1 = multiprocessing.Process(target=producer, args=(q,))
		p2 = multiprocessing.Process(target=consumer, args=(q,))

		p1.start()
		p2.start()
		p1.join()
		p2.join()

		
		
